<?php
session_start();
error_reporting(0);
include('includes/config.php');

if(strlen($_SESSION['alogin']) == "") {   
    header("Location: index.php"); 
} else {
    if(isset($_POST['submit'])) {
        // Check if file was uploaded without errors
        if(isset($_FILES['ods_file']) && $_FILES['ods_file']['error'] === UPLOAD_ERR_OK) {
            // Get file details
            $fileTmpName = $_FILES['ods_file']['tmp_name'];
            
            // Read the ODS file
            if(($handle = fopen($fileTmpName, "r")) !== FALSE) {
               
                
                // Loop through each row of the file
                while(($data = fgetcsv($handle, 10000, "\t")) !== FALSE) { 
                    // Extract data from each column
                    $id = $data[0];
                    $studentid = $data[1];
                    $class = $data[2];
                    $subjectid = $data[3];
                    $marks = $data[4];
                    $postingdate = $data[5];
                    $updationdate = $data[6];

                    // Insert data into database
                    $sql = "INSERT INTO tblresultss (id, StudentId, ClassId, SubjectId, marks, PostingDate, UpdationDate) VALUES (:id, :studentid, :class, :subjectid, :marks, :postingdate, :updationdate)";
                    $query = $dbh->prepare($sql);
                    $query->bindParam(':id', $id, PDO::PARAM_INT);
                    $query->bindParam(':studentid', $studentid, PDO::PARAM_INT);
                    $query->bindParam(':class', $class, PDO::PARAM_INT);
                    $query->bindParam(':subjectid', $subjectid, PDO::PARAM_INT);
                    $query->bindParam(':marks', $marks, PDO::PARAM_INT);
                    $query->bindParam(':postingdate', $postingdate, PDO::PARAM_STR);
                    $query->bindParam(':updationdate', $updationdate, PDO::PARAM_STR);
                    
                    $query->execute();
                }
                fclose($handle);
                $msg = "ODS file data inserted successfully.";
            } else {
                $error = "Error opening ODS file.";
            }
        } else {
            $error = "File upload error occurred.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SRMS Admin | Declare Result </title>
    <link rel="stylesheet" href="css/bootstrap.min.css" media="screen">
    <link rel="stylesheet" href="css/font-awesome.min.css" media="screen">
    <link rel="stylesheet" href="css/main.css" media="screen">
</head>
<body class="top-navbar-fixed">
<div class="main-wrapper">
    <!-- ========== TOP NAVBAR ========== -->
    <?php include('includes/topbar.php');?>
    <!-- ========== WRAPPER FOR BOTH SIDEBARS & MAIN CONTENT ========== -->
    <div class="content-wrapper">
        <div class="content-container">
            <!-- ========== LEFT SIDEBAR ========== -->
            <?php include('includes/leftbar-1.php');?>
            <!-- /.left-sidebar -->
            <div class="main-page">
                <div class="container-fluid">
                    <div class="row page-title-div">
                        <div class="col-md-6">
                            <h2 class="title"> Result Entry</h2>
                        </div>
                    </div>
                    <div class="row breadcrumb-div">
                        <div class="col-md-6">
                            <ul class="breadcrumb">
                                <li><a href="dashboard-teacher1.php"><i class="fa fa-home"></i> Home</a></li>
                                <li><a href="#">Results</a></li>
                                <li class="active"></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="content-wrapper">
                    <div class="content-container">
                        <!-- Page Title and Breadcrumbs -->
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-md-12">
                                    <h2 class="title">Result Entry</h2>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <form class="form-horizontal" method="post" enctype="multipart/form-data">
                                        <div class="form-group">
                                            <label for="department" class="col-sm-2 control-label">Department</label>
                                            <div class="col-sm-10">
                                                <select name="department" class="form-control" id="department" onchange="getStudent(this.value);" required>
                                                    <option value="">Select Department</option>
                                                    <?php $sql = "SELECT * from tblclassess";
                                                    $query = $dbh->prepare($sql);
                                                    $query->execute();
                                                    $results = $query->fetchAll(PDO::FETCH_OBJ);
                                                    if($query->rowCount() > 0) {
                                                        foreach($results as $result) { ?>
                                                            <option value="<?php echo htmlentities($result->id); ?>"><?php echo htmlentities($result->ClassName); ?>&nbsp; Year-<?php echo htmlentities($result->ClassNameNumeric); ?>&nbsp; Section-<?php echo htmlentities($result->Section); ?></option>
                                                        <?php }
                                                    } ?>
                                                </select>
                                            </div>
                                        </div>
                                        <!-- ODS File Upload -->
                                        <div class="form-group">
                                            <label for="ods_file" class="col-sm-2 control-label">Upload ODS</label>
                                            <div class="col-sm-10">
                                                <input type="file" name="ods_file" id="ods_file" accept=".ods">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-offset-2 col-sm-10">
                                                <button type="submit" name="submit" id="submit" class="btn btn-primary">Import</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <!-- JavaScript imports -->
                        <script src="js/jquery/jquery-2.2.4.min.js"></script>
                        <script src="js/bootstrap/bootstrap.min.js"></script>
                        <!-- Other JavaScript imports -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
